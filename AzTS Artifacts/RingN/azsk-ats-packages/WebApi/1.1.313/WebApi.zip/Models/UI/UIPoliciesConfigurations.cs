﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Secure Template feature configuration for UI.
    /// </summary>
    public class UIPoliciesConfigurations
    {
        /// <summary>
        /// Gets or sets a value indicating whether Policies feature is enabled.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating VNext link for policies.
        /// </summary>
        public string PoliciesRedirectionLink { get; set; } = string.Empty;
    }
}