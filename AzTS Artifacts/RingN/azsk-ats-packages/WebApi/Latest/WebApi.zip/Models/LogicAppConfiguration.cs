﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Logic App Configurations for automatings tasks.
    /// </summary>
    public class LogicAppConfiguration
    {
        /// <summary>
        /// Gets or sets graph API endpoint.
        /// </summary>
        public const string ConfigName = "LogicAppConfiguration";

        /// <summary>
        /// Gets or sets the URL for triggering mail send.
        /// </summary>
        public string EmailNotificationAPI { get; set; } = string.Empty;
    }
}