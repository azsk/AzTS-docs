﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Control Metadata Editor feature configuration for UI.
    /// </summary>
    public class UIControlEditorFeatureConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether user Control Metadata Editor is supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating whether user Bulk Edit in Control Metadata Editor is supported or not.
        /// </summary>
        public bool IsBulkEditEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating whether Edit of Custom Fields in Control Metadata Editor is supported or not.
        /// </summary>
        public bool IsEditCustomFieldsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating whether adding of new Control in Control Metadata Editor is supported or not.
        /// </summary>
        public bool IsAddNewControlEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets the short word limit for CMET.
        /// </summary>
        public int ShortWordLimit { get; set; } = 1000;

        /// <summary>
        /// Gets or sets the medium word limit for CMET.
        /// </summary>
        public int MediumWordLimit { get; set; } = 2000;

        /// <summary>
        /// Gets or sets the long word limit for CMET.
        /// </summary>
        public int LongWordLimit { get; set; } = 5000;

    }
}