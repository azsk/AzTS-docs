﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// New Feature Modal configuration for UI.
    /// This configures the modal that pops up whenever a significant UI update is released.
    /// </summary>
    public class UINewFeatureModalConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether feature is supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets URL of raw markdown content.
        /// </summary>
        public string SourceURL { get; set; }

        /// <summary>
        /// Gets or sets version of the New Feature release.
        /// Increment the number in the release in which you wish to show the Modal.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the URL of readable markdown.
        /// </summary>
        public string RedirectionURL { get; set; }

        /// <summary>
        /// Gets or sets whether the modal is visible after the first visit.
        /// </summary>
        public bool IsRecurring { get; set; }
    }
}