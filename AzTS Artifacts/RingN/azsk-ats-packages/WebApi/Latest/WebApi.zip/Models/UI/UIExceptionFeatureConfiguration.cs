namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{
    using System.Collections.Generic;

    /// <summary>
    /// UI exception feature configuration.
    /// </summary>
    public class UIExceptionFeatureConfiguration
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UIExceptionFeatureConfiguration"/> class.
        /// </summary>
        public UIExceptionFeatureConfiguration()
        {
            this.CustomExceptionTypes = new List<CustomExceptionType>();
        }

        /// <summary>
        /// Gets or sets a value indicating whether exception feature is enabled or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets the help page URL for the exception feature. Example: "https://wiki.exception-portal".
        /// </summary>
        public string HelpPageUrl { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the default target for exception. Example: "https://exception-portal" or "mailto:foo@bar.com?subject=abc&body=xyz".
        /// </summary>
        public string DefaultExceptionTarget { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the default instructions to be displayed on UI when user uses the attestation feature.
        /// </summary>
        public string DefaultInstructions { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a warning text to describe any potential effects on attesting Controls.
        /// </summary>
        public string WarningText { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets details of custom exception types to be supported by UI.
        /// </summary>
        public List<CustomExceptionType> CustomExceptionTypes { get; set; }

    }

    /// <summary>
    /// Label and other instruction for a custom exception type.
    /// </summary>
    public class CustomExceptionType
    {
        public CustomExceptionType()
        {
          this.EligibleTagsMetadata = new List<ExceptionsEligibleTagMetadata>();
        }

        /// <summary>
        /// Gets or sets a key associated with the exception type. This string should be in lowercase alphabetic characters (and, without whitespaces). This is to uniquely identify the exception type in the UI.
        /// </summary>
        public string Key { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a label associated with the exception type. It is this text that is displayed on the screen, in the list of supported exception types.
        /// </summary>
        public string Text { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets an identifier associated with the exception type. It is this property that is used by both, the API and UI for handling a given exception type.
        /// </summary>
        public string Data { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a value indicating whether this exception type is to be enabled for all tags.
        /// </summary>
        public bool IsEnabledForAllTags { get; set; } = false;

        /// <summary>
        /// Gets or sets an exception-type specific target. Example: "https://exception-portal" or "mailto:foo@bar.com?subject=abc&body=xyz".
        /// This will take precedence over any default targets, for this exception type.
        /// </summary>
        public string CustomExceptionTarget { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets exception-type specific instructions to be displayed on UI when user uses the attestation feature.
        /// This will take precedence over any default instructions, for this exception type.
        /// </summary>
        public string CustomInstructions { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets Note for the exception-type specific instructions to be displayed on UI when user uses the attestation feature.
        /// This will take precedence over any default notes, for this exception type.
        /// </summary>
        public string CustomNote { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a Note URL for the exception-type specific instructions to be displayed on UI when user uses the attestation feature.
        /// This will take precedence over any default notes URL, for this exception type.
        /// </summary>
        public string CustomNoteURL { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets all eligible tags (along with additional metadata), that this custom exception type can support.
        /// </summary>
        public List<ExceptionsEligibleTagMetadata> EligibleTagsMetadata { get; set; }
    }

    public class ExceptionsEligibleTagMetadata
    {
        /// <summary>
        /// Gets or sets that name of a tag that the enclosing custom exception type can support.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the target for a specific exception-type/tag combination.
        /// Example: "https://exception-portal" or "mailto:foo@bar.com?subject=abc&body=xyz".
        /// This will take precedence over any other targets.
        /// </summary>
        public string ExceptionTarget { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the instruction to be displayed on UI when user uses the attestation feature, for a specific exception-type/tag combination.
        // This will take precedence over any other instructions.
        /// </summary>
        public string Instructions { get; set; } = string.Empty;
    }
}
