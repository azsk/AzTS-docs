﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// AAD feature configuration for UI.
    /// </summary>
    public class UIEntraIdConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether AAD feature is enabled.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating VNext link for Entra ID.
        /// </summary>
        public string EntraIdRedirectionLink { get; set; } = string.Empty;
    }
}