namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{
    using System.Collections.Generic;
    using Scanner.API.Models.KR51;
    using Scanner.API.Models.UI;

    /// <summary>
    /// Model class for UI configuration.
    /// </summary>
    public class UIConfigurationBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UIConfigurationBase"/> class.
        /// </summary>
        public UIConfigurationBase()
        {
            this.CustomViewConfigurations = new List<CustomViewConfiguration>();
            this.ExceptionFeatureConfiguration = new UIExceptionFeatureConfiguration();
            this.UserImpersonationFeatureConfiguration = new UIUserImpersonationFeatureConfiguration();
            this.ControlEditorFeatureConfiguration = new UIControlEditorFeatureConfiguration();
            this.ExternalControlsConfiguration = new UIExternalControlsConfiguration();
            this.ComplianceInitiativeConfiguration = new UIComplianceInitiativeConfiguration();
            this.TutorialConfiguration = new UITutorialConfiguration();
            this.SecureTemplateConfiguration = new UISecureTemplateConfiguration();
            this.NewFeatureModalConfiguration = new UINewFeatureModalConfiguration();
            this.RemediationFeatureConfiguration = new UIRemediationFeatureConfiguration();
            this.OnDemandScanProgressIndicatorConfiguration = new UIOnDemandScanProgressIndicatorConfiguration();
        }

        /// <summary>
        /// Configuration name.
        /// </summary>
        public const string ConfigName = "UIConfigurations";

        /// <summary>
        /// Gets or sets the help URL for ARM.
        /// </summary>
        public string AzureResourceManagerHelpURL { get; set; } = "https://aka.ms/azts/ARM-HelpURL";

        /// <summary>
        /// Gets or sets graph API endpoint.
        /// </summary>
        public string GraphAPI { get; set; } = "https://graph.microsoft.com";

        /// <summary>
        /// Gets or sets azure API endpoint.
        /// </summary>
        public string AzureAPI { get; set; } = "https://portal.azure.com";

        /// <summary>
        /// Gets or sets whether the setup is on an external tenant.
        /// </summary>
        public bool IsExternalTenantSetup { get; set; } = true;

        /// <summary>
        /// Gets or sets whether the DevOps scanner is enabled.
        /// </summary>
        public bool IsDevOpsScannerEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets whether the ManagementGroupFilterEnabled is enabled.
        /// </summary>
        public bool IsManagementGroupFilterEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets whether the setup is a multi tenant setup.
        /// </summary>
        public bool IsMultiTenantSetup { get; set; } = false;

        /// <summary>
        /// Gets or sets whether the Service Tree data is available for the setup.
        /// </summary>
        public bool IsServiceTreeDataAvailable { get; set; } = false;

        /// <summary>
        /// Gets or sets link to the issue tracker URL.
        /// </summary>
        public string IssueTrackerURL { get; set; } = "https://aka.ms/AzTSIssueTracker";

        /// <summary>
        /// Gets or sets link to the privacy policy URL.
        /// </summary>
        public string PrivacyPolicyURL { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets link to the control remediation help URL.
        /// </summary>
        public string ControlRemediationHelpURL { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets subscription count in a page.
        /// </summary>
        public int SubCountInPage { get; set; } = 30;

        /// <summary>
        /// Gets or sets AzTS support email.
        /// </summary>
        public string IssueSupportMail { get; set; } = "aztssup@microsoft.com";

        /// <summary>
        /// Gets or sets default baseline tag.
        /// </summary>
        public string DefaultBaseline { get; set; } = "ActiveBaseline";

        /// <summary>
        /// Gets or sets control Wiki base URL.
        /// </summary>
        public string ControlWikiBaseURL { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets configuration of custom view supported by UI.
        /// </summary>
        public List<CustomViewConfiguration> CustomViewConfigurations { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's exception feature .
        /// </summary>
        public UIExceptionFeatureConfiguration ExceptionFeatureConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's remediaton feature .
        /// </summary>
        public UIRemediationFeatureConfiguration RemediationFeatureConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's user impersonation feature.
        /// </summary>
        public UIUserImpersonationFeatureConfiguration UserImpersonationFeatureConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's Control Metadata Editor feature.
        /// </summary>
        public UIControlEditorFeatureConfiguration ControlEditorFeatureConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's Externally Scanned Controls feature.
        /// </summary>
        public UIExternalControlsConfiguration ExternalControlsConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's Compliance Initiative feature.
        /// </summary>
        public UIComplianceInitiativeConfiguration ComplianceInitiativeConfiguration { get; set; }

        public UIComplianceInitiativeConfiguration ComplianceInitiativeFeatureConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration of UI's Tutorial feature in the help section.
        /// </summary>
        public UITutorialConfiguration TutorialConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration related to Secure Templates.
        /// </summary>
        public UISecureTemplateConfiguration SecureTemplateConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration related to Policies.
        /// </summary>
        public UIPoliciesConfigurations PoliciesConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configuration related to AAD.
        /// </summary>
        public UIEntraIdConfiguration EntraIdConfiguration { get; set; }

        /// <summary>
        /// Gets or sets New Feature Modal configurations.
        /// </summary>
        public UINewFeatureModalConfiguration NewFeatureModalConfiguration { get; set; }

        /// <summary>
        /// Gets or sets configurations of UI's on demand scan progress indicator feature.
        /// </summary>
        public UIOnDemandScanProgressIndicatorConfiguration OnDemandScanProgressIndicatorConfiguration { get; set; }

        /// <summary>
        /// Gets or sets KR51 Control Config Settings.
        /// </summary>
        public KR51ControlsConfigSettings KR51ControlsConfigSettings { get; set; }

        /// <summary>
        /// Gets or sets UI custom heading.
        /// </summary>
        public string CustomUIHeading { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets MDC info link.
        /// </summary>
        public string MdcInfoLink { get; set; } = string.Empty;
    }
}
