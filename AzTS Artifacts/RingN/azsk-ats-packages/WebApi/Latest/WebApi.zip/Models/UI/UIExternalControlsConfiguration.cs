﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// External Control feature configuration for UI.
    /// </summary>
    public class UIExternalControlsConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether user External Controls are supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;
    }
}