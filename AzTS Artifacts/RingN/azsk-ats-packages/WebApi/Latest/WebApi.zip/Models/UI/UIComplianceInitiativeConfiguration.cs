﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Compliance Initiative feature configuration for UI.
    /// </summary>
    public class UIComplianceInitiativeConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether Compliance Initiative feature is supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets description of the Compliance Initiative option provided in UI.
        /// </summary>
        public string Description { get; set; }
    }
}