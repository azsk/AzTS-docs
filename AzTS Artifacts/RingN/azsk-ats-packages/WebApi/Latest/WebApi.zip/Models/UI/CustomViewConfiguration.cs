namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Configuration of custom view supported by UI.
    /// </summary>
    public class CustomViewConfiguration
    {
        /// <summary>
        /// Gets or sets name of the view.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets text to be displayed in the Baseline Control Filter label.
        /// </summary>
        public string BaselineControlFilterLabel { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets a value indicating whether the baselineControlFilterToggle can be turned on/off or not. This toggle is disabled for cseopilot view.
        /// </summary>
        public bool IsBaselineControlFilterToggleEnabled { get; set; } = true;
    }
}
