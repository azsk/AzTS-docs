﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Tutorial feature configuration for UI.
    /// </summary>
    public class UITutorialConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether tutorial docs feature is supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets a value indicating the link pointing to the tutorials.
        /// </summary>
        public string TutorialDocs { get; set; } = "";
    }
}