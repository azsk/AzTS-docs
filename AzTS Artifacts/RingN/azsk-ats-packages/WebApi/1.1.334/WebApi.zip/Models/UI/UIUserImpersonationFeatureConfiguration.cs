namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// User impersonation feature configuration for UI.
    /// </summary>
    public class UIUserImpersonationFeatureConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether user Impersonation is supported or not.
        /// </summary>
        public bool IsEnabled { get; set; } = false;

        /// <summary>
        /// Gets or sets user Impersonation endpoint - Just the endpoint, not the complete URL.
        /// </summary>
        public string Endpoint { get; set; } = "/admin";
    }
}
