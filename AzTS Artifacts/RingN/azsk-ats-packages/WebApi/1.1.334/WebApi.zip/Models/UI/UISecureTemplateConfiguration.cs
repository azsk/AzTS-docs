﻿namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{

    /// <summary>
    /// Secure Template feature configuration for UI.
    /// </summary>
    public class UISecureTemplateConfiguration
    {
        /// <summary>
        /// Gets or sets a value indicating whether Secure Templates feature is enabled.
        /// </summary>
        public bool IsEnabled { get; set; } = false;
    }
}