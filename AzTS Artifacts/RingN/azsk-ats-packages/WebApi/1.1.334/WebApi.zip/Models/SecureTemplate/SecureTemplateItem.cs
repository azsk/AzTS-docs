namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{
    using System.Collections.Generic;

    /// <summary>
    /// Class to model a single secure template.
    /// </summary>
    public class SecureTemplateItem
    {
        /// <summary>
        /// Gets or sets the name of resourceType for which the template exists.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the name of actual service name as mentioned in Control Configurations.
        /// </summary>
        public string Service { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the secure template is enabled.
        /// </summary>
        public bool IsEnabled { get; set; }

        /// <summary>
        /// Gets or sets the template description of single resourceType.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the link to secure template.
        /// </summary>
        public string Link { get; set; }

        /// <summary>
        /// Gets or sets the image link of resourceType.
        /// </summary>
        public string ImageLink { get; set; }

        /// <summary>
        /// Gets or sets the ControlIds covered in secure template.
        /// </summary>
        public List<string> ControlList { get; set; }

        /// <summary>
        /// Gets or sets the additional information about controls.
        /// </summary>
        public List<ControlInfoSecureTemplate> ControlInfoList { get; set; }

        /// <summary>
        /// Gets or sets the detailed description of single resourceType.
        /// </summary>
        public string Details { get; set; }

    }
}
