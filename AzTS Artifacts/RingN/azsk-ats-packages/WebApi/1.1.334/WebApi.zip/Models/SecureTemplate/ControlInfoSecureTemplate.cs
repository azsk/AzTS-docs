namespace Microsoft.AzSK.ATS.WebAPI.Models.UI
{
    using System.Collections.Generic;

    /// <summary>
    /// Class to model additional information for controls covered in the secure template.
    /// </summary>
    public class ControlInfoSecureTemplate
    {
        /// <summary>
        /// Gets or sets the ControlId to identify the control.
        /// </summary>
        public string ControlId { get; set; }

        /// <summary>
        /// Gets or sets the DisplayName.
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets custom object for UI.
        /// </summary>
        public UIControlObject UIControlObject { get; set; }

        
        /// <summary>
        /// Gets or sets a value indicating whether the control is supported in the Secure Template.
        /// </summary>
        public bool IsSupported { get; set; }
    }

    /// <summary>
    /// Custom object for displaying in UI.
    /// </summary>
    public class UIControlObject
    {
        /// <summary>
        /// Gets or sets the ControlId to identify the control.
        /// </summary>
        public string ControlId { get; set; }

        /// <summary>
        /// Gets or sets the DisplayName.
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the rationale behind the control.
        /// </summary>
        public string Rationale { get; set; }

    }
}
