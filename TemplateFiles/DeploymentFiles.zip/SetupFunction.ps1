function Install-AzSKTenantSecuritySolutionConsolidated
{
    Param(

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $MIHostingSubId,

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $MIHostingRGName,

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $MIName,

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $HostTenantId,

        [string[]]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="List of subscription(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target subscription.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="List of subscription(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target subscription.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="List of subscription(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target subscription.")]
        [Alias("SubscriptionsToScan")]
        $TargetSubscriptionIds = @(),

        [string[]]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="List of target management group(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target management group. Providing root management group name is recommended.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="List of target management group(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target management group. Providing root management group name is recommended.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="List of target management group(s) to be scanned by Azure Tenant Security scanning solution. Scanning identity will be granted 'Reader' access on target management group. Providing root management group name is recommended.")]
        [Alias("ManagementGroupsToScan")]
        $TargetManagementGroupNames = @(),

        [switch]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        $GrantGraphPermissionToScanIdentity = $false,

        [switch]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Specify if internal managed identity to be granted Graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Specify if internal managed identity to be granted Graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Specify if internal managed identity to be granted Graph permission.")]
        $GrantGraphPermissionToInternalIdentity = $false,

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Subscription id in which Azure Tenant Security Solution needs to be installed.")]
        $SubscriptionId,

        [string]
		[Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Name of ResourceGroup where setup resources will be created.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Name of ResourceGroup where setup resources will be created.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Name of ResourceGroup where setup resources will be created.")]
		$ScanHostRGName = "AzSK-AzTS-RG",

        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "Default",  HelpMessage="Location where all resources and scanner MI will get created. Default location is EastUS2.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI",  HelpMessage="Location where all resources and scanner MI will get created. Default location is EastUS2.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility",  HelpMessage="Location where all resources and scanner MI will get created. Default location is EastUS2.")]
        $Location,

        [string]
        [Parameter(Mandatory = $false, ParameterSetName = "Default")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility")]
        $TemplateFilePath = ".\AzTSDeploymentTemplate.json",

        [Hashtable]
        [Parameter(Mandatory = $false, ParameterSetName = "Default")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility")]
        $TemplateParameters = @{},

        [switch]
        [Parameter(Mandatory = $false,  ParameterSetName = "Default", HelpMessage="Usage telemetry captures anonymous usage data and sends it to Microsoft servers. This will help in improving the product quality and prioritize meaningfully on the highly used features.")]
        [Parameter(Mandatory = $false,  ParameterSetName = "AzTSUI", HelpMessage="Usage telemetry captures anonymous usage data and sends it to Microsoft servers. This will help in improving the product quality and prioritize meaningfully on the highly used features.")]
        [Parameter(Mandatory = $false,  ParameterSetName = "CentralVisibility", HelpMessage="Usage telemetry captures anonymous usage data and sends it to Microsoft servers. This will help in improving the product quality and prioritize meaningfully on the highly used features.")]
        $SendUsageTelemetry = $false,

        [switch]
        [Parameter(Mandatory = $false,  ParameterSetName = "Default", HelpMessage="Switch to validate required modules. If passed command will check needed modules with required version, will install required modules if not available in the system.")]
        [Parameter(Mandatory = $false,  ParameterSetName = "AzTSUI", HelpMessage="Switch to validate required modules. If passed command will check needed modules with required version, will install required modules if not available in the system.")]
        [Parameter(Mandatory = $false,  ParameterSetName = "CentralVisibility", HelpMessage="Switch to validate required modules. If passed command will check needed modules with required version, will install required modules if not available in the system.")]
        $SetupAzModules = $false,

        [switch]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Specify if user managed identity has Graph permission. This is to exclude controls dependent on Graph API response from the scan result, if scanner identity does not have graph permission.")]
        $ScanIdentityHasGraphPermission = $false,

        [string[]]
        [Parameter(Mandatory = $true, ParameterSetName = "Default", HelpMessage="Email ids to which alert notification should be sent.")]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Email ids to which alert notification should be sent.")]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Email ids to which alert notification should be sent.")]
        [Alias("SREEmailIds")]
        $SendAlertNotificationToEmailIds = @(),

        [string]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Azure environment in which Azure Tenant Security Solution needs to be installed. The acceptable values for this parameter are: AzureCloud, AzureGovernmentCloud")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Azure environment in which Azure Tenant Security Solution needs to be installed. The acceptable values for this parameter are: AzureCloud, AzureGovernmentCloud")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Azure environment in which Azure Tenant Security Solution needs to be installed. The acceptable values for this parameter are: AzureCloud, AzureGovernmentCloud")]
        [ValidateSet("AzureCloud", "AzureGovernmentCloud")]
        $AzureEnvironmentName = "AzureCloud",

        [switch]
        [Parameter(Mandatory = $false, HelpMessage="Switch to enable vnet integration. Resources required for vnet setup will be deployed only if this switch is ON.")]
        $EnableVnetIntegration = $false,

        [switch]
        [Parameter(Mandatory = $false, ParameterSetName = "Default", HelpMessage="Switch to enable AzTS auto updater. Autoupdater helps to get latest feature released for AzTS components covering updates for security controls. If this is disabled, you can manually update AzTS components by re-running setup command.")]
        [Parameter(Mandatory = $false, ParameterSetName = "AzTSUI", HelpMessage="Switch to enable AzTS auto updater. Autoupdater helps to get latest feature released for AzTS components covering updates for security controls. If this is disabled, you can manually update AzTS components by re-running setup command.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Switch to enable AzTS auto updater. Autoupdater helps to get latest feature released for AzTS components covering updates for security controls. If this is disabled, you can manually update AzTS components by re-running setup command.")]
        [Alias("EnableAutoUpdates")]
        $EnableAutoUpdater,

        [switch]
        [Parameter(Mandatory = $true, ParameterSetName = "AzTSUI", HelpMessage="Switch to enable AzTS UI. AzTS UI is created to see compliance status for subscription owners and perform adhoc scan.")]
        [Parameter(Mandatory = $false, ParameterSetName = "CentralVisibility", HelpMessage="Switch to enable AzTS UI. AzTS UI is created to see compliance status for subscription owners and perform adhoc scan.")]
        $EnableAzTSUI,

        [switch]
        [Parameter(Mandatory = $false, HelpMessage="Switch to enable WAF. Resources required for implementing WAF will be deployed only if this switch is ON.")]
        $EnableWAF = $false,
        
        [string]
        [Parameter(Mandatory = $true, ParameterSetName = "CentralVisibility", HelpMessage="Connection string of the storage account to be used to store the scan logs centrally.")]
        [Alias("StorageAccountConnectionString")]
        $CentralStorageAccountConnectionString
    )

    Begin
    {
        # Load AzTS Setup script in session
        $inputParams = $PSBoundParameters
        . ".\AzTSSetup.ps1"
        Write-Host $([Constants]::DoubleDashLine + "`r`nMethod Name: Install-AzSKTenantSecuritySolutionConsolidated `r`nInput Parameters: $(($inputParams | Out-String).TrimEnd()) `r`n") -ForegroundColor $([Constants]::MessageType.Info) 
        Write-Host $([Constants]::DoubleDashLine) -ForegroundColor $([Constants]::MessageType.Info) 
        Write-Host "Starting Azure Tenant Security Solution installation. This may take 5 mins...`n" -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::QuickInstallSolutionInstructionMsg) -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::DoubleDashLine)

        if ($SetupAzModules)
        {
            Write-Host $([Constants]::SingleDashLine)
            Write-Host "**Step 0**: Validate prerequisites." -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host $([Constants]::SingleDashLine)
            $allPrerequisiteMet = Setup-Prerequisites

            if (-not $allPrerequisiteMet)
            {
                Write-Host "One or more required Az modules are missing. AzTS setup will be skipped." -ForegroundColor $([Constants]::MessageType.Error)
                break;
            }

        }


        # Disconnect from current AD/Azure session
        try
        {
            #Disconnect-AzAccount
            #Disconnect-AzureAD
        }
        catch
        {
            # If user is not already connected to Azure, Disconnect command will return an error. In this case, please ignore the error and continue to next step. 
        }

        # Connect to AzureAD and AzAccount
        #Connect-AzAccount -Tenant $HostTenantId
        #Connect-AzureAD -TenantId $HostTenantId

        ##############################################################################
        Write-Host $([Constants]::DoubleDashLine)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "**Step 1.A**: Set up scanning identity." -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "Setting up Azure Tenant Security scanner identity...`n" -ForegroundColor $([Constants]::MessageType.Info)
        # Step 1: Setting up scanning identity  
        # 1- Create scanner MI and grant 'Reader' permission on target subscriptions.
        $UserAssignedIdentity = Set-AzSKTenantSecuritySolutionScannerIdentity -SubscriptionId $MIHostingSubId `
                                                                                -ResourceGroupName $MIHostingRGName `
                                                                                -Location $Location `
                                                                                -UserAssignedIdentityName $MIName `
                                                                                -TargetSubscriptionIds $TargetSubscriptionIds `
                                                                                -TargetManagementGroupNames $TargetManagementGroupNames `
                                                                                -QuickSetup

        if ([string]::IsNullOrWhiteSpace($UserAssignedIdentity))
        {
            # No need to log Error message, it's done by the above command itself
            # If UserAssignedIdentity is null stop script execution, as it represent error occurred while setting up scanner identity
            return;
        }

        Write-Host $([Constants]::SingleDashLine)
        Write-Host "**Step 1.B**: Grant Graph permissions to scanning identity." -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::SingleDashLine)

        $graphPermissionGranted = $false
        if ($GrantGraphPermissionToScanIdentity -eq $true)
        {
            try{
                Grant-AzSKGraphPermissionToUserAssignedIdentity -UserAssignedIdentityObjectId $UserAssignedIdentity.PrincipalId -MSGraphPermissionsRequired @("PrivilegedAccess.Read.AzureResources", "Directory.Read.All") -ADGraphPermissionsRequired @("Directory.Read.All")
                $graphPermissionGranted = $true
            }
            catch{
                $graphPermissionGranted = $false
            }
        }
        else
        {
            $graphPermissionGranted = $false
            Write-Host "Skipped: Graph permissions not granted to scanner identity." -ForegroundColor $([Constants]::MessageType.Warning)
            Write-Host ([constants]::ScanningIdentitySetupNextSteps) -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host $([Constants]::SingleDashLine)
        }

        # ***** Initialize required parameters ******

        # Subscription id in which Azure Tenant Security Solution needs to be installed.
        $HostSubscriptionId = $SubscriptionId 

        # Resource group name in which Azure Tenant Security Solution needs to be installed.
        $HostResourceGroupName = $ScanHostRGName

        # Location in which resources needs to be created.
        # Note: For better performance, we recommend hosting the Central Scanner MI and resources setup using AzTS Soln installation command in one location.
        $Location = $Location # e.g. EastUS2

        # Azure environment in which Azure Tenant Security Solution needs to be installed. The acceptable values for this parameter are: AzureCloud, AzureGovernmentCloud
        $AzureEnvironmentName = $AzureEnvironmentName

        # Specify if scanner MI has Graph permission. This is to exclude controls dependent on Graph API reponse from the scan result, if scanner identity does not have graph permission.
        $ScanIdentityHasGraphPermission = $graphPermissionGranted

        # The installation creates alert for monitoring health of the AzTS Soln.
        # Comma-separated list of user email ids who should be sent the monitoring email.
        $SendAlertNotificationToEmailIds =  $SendAlertNotificationToEmailIds
        ##############################################################################

        # Step 2: Create Azure AD application for secure authentication 
        # Setup AD application for AzTS UI and API
        Write-Host $([Constants]::DoubleDashLine)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "**Step 2**: Setup AD application for AzTS UI and API." -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::SingleDashLine)

        if ($EnableAzTSUI -eq $true)
        {
            $ADApplicationDetails = Set-AzSKTenantSecurityADApplication -SubscriptionId $HostSubscriptionId -ScanHostRGName $HostResourceGroupName -QuickSetup

            if ($ADApplicationDetails -eq $null)
            {
                # No need to log Error message, it's done by the above command itself
                # If ADApplicationDetails is null stop script execution, as it represent error occurred while setting up AD App
                return;
            }
            # Else $ADApplicationDetails object contains UI & Web API AD App details
        }
        else{
            Write-Host "Skipped: This step has been skipped as AzTS UI is not enabled for the setup." -ForegroundColor $([Constants]::MessageType.Warning)
            Write-Host $([Constants]::SingleDashLine)
        }
        
        ##############################################################################
        # Step 3. Set context and validate you have 'Owner' access on subscription where solution needs to be installed ****
        Write-Host $([Constants]::DoubleDashLine)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "**Step 3.A**: Install AzTS setup." -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "Started setting up Azure Tenant Security Solution..." -ForegroundColor $([Constants]::MessageType.Info)
        # Run Setup Command
        # i) Set the context to hosting subscription
        $azContext = Set-AzContext -SubscriptionId  $HostSubscriptionId

        # ii) Run install solution command 
        # Note : To install AzTS setup with vnet integration, uncomment switch '-EnableVnetIntegration' and then run the installation command
        # Note : To install AzTS setup with WAF enabled, uncomment switch '-EnableWAF' and then run the installation command
        $CommandArguments = @{
                            SubscriptionId = $HostSubscriptionId
                            ScanHostRGName = $HostResourceGroupName
                            Location = $Location
                            ScanIdentityId = $UserAssignedIdentity.Id 
                            AzureEnvironmentName = $AzureEnvironmentName
                            SendAlertNotificationToEmailIds  = $SendAlertNotificationToEmailIds
                            TemplateFilePath = $TemplateFilePath
                            TemplateParameters = $TemplateParameters
                            SendUsageTelemetry = $SendUsageTelemetry
                            ScanIdentityHasGraphPermission = $ScanIdentityHasGraphPermission
                            EnableAutoUpdater = $EnableAutoUpdater 
                            EnableVnetIntegration = $EnableVnetIntegration
                            EnableWAF = $EnableWAF
                            SkipInstructions = $true
                        }

        if ($EnableAzTSUI -eq $true)
        {
            $CommandArguments += @{
                EnableAzTSUI = $true
                WebAPIAzureADAppId = $ADApplicationDetails.WebAPIAzureADAppId
                UIAzureADAppId = $ADApplicationDetails.UIAzureADAppId
            }
        }

        if (-not [string]::IsNullOrWhiteSpace($CentralStorageAccountConnectionString))
        {
            $CommandArguments.Add('CentralStorageAccountConnectionString', $CentralStorageAccountConnectionString)
        }

        $DeploymentResult = Install-AzSKTenantSecuritySolution @CommandArguments

        if ($DeploymentResult -eq $null)
        {
            # No need to log Error message, it's done by the above command itself
            # If deployment result is null stop script execution, as it represent error occurred while deploying AzTS resources
            return;
        }

        Write-Host $([Constants]::DoubleDashLine)
        Write-Host $([Constants]::SingleDashLine)
        Write-Host "**Step 3.B**: Grant internal MI required Graph permissions." -ForegroundColor $([Constants]::MessageType.Info)
        Write-Host $([Constants]::SingleDashLine)

        # iii) Save internal user-assigned managed identity name generated using below command. This will be used to grant Graph permission to internal MI.
        $InternalIdentityObjectId = $DeploymentResult.Outputs.internalMIObjectId.Value

        # iv) Grant internal MI 'User.Read.All' permission.

        # **Note:** To complete this step, signed-in user must be a member of one of the following administrator roles:
        # Required Permission: Global Administrator or Privileged Role Administrator. 
        # If you do not have the required permission, please contact your administrator.
        # Read more about this under the section "Step 6 of 6. Run Setup Command" in GitHub doc.

        if ($GrantGraphPermissionToInternalIdentity -eq $true)
        {
            # No need for exception handling, present in command itself
            Grant-AzSKGraphPermissionToUserAssignedIdentity `
                    -UserAssignedIdentityObjectId  $InternalIdentityObjectId  `
                    -MSGraphPermissionsRequired @('User.Read.All')
           
        }
        else
        {
            Write-Host "Skipped: Graph permissions not granted to internal MI identity." -ForegroundColor $([Constants]::MessageType.Warning)
            Write-Host ([constants]::InternalIdentitySetupNextSteps) -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host $([Constants]::SingleDashLine)
        }

        $deploymentOutputs = $DeploymentResult.Outputs | ConvertTo-Json | ConvertFrom-Json
        $UIUrl = [string]::Empty

        if($EnableAzTSUI -and $deploymentOutputs.PSObject.Properties.Name.Contains("uiAppName"))
        {
            $azureUIAppName= $DeploymentResult.Outputs.uiAppName.Value
            $UIUrl =  $([string]::Concat($([string]::Format($AzureEnvironmentAppServiceURI.$AzureEnvironmentName, $azureUIAppName)), "/"))
        }
        
        Write-Host "$([Constants]::DoubleDashLine)" #-ForegroundColor $([Constants]::MessageType.Info)
        if($EnableAzTSUI -and $EnableWAF)
        {
            $AzTSUIFrontDoorUrl = $DeploymentResult.Outputs.azTSUIFrontDoorUrl.Value
            Write-Host "$([Constants]::NextSteps -f $AzTSUIFrontDoorUrl)" -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host "IMPORTANT: AzTS UI will be available only after completing 'step a' listed under Next steps. AzTS UI URL for your tenant: $($AzTSUIFrontDoorUrl)" -ForegroundColor $([Constants]::MessageType.Warning)
        }
        elseif($EnableAzTSUI)
        {
            Write-Host "$([Constants]::NextSteps -f $UIUrl)" -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host "IMPORTANT: AzTS UI will be available only after completing 'step a' listed under Next steps. AzTS UI URL for your tenant: $($UIUrl)" -ForegroundColor $([Constants]::MessageType.Warning)
        }
        else 
        {
            Write-Host "$([Constants]::NextSteps -f $UIUrl)" -ForegroundColor $([Constants]::MessageType.Info)
        }
        Write-Host "$([Constants]::DoubleDashLine)"

    }
}

function Setup-Prerequisites {
    <#
        .SYNOPSIS
        Checks if all required Az modules are present, else, sets them up.
        .DESCRIPTION
        Checks if all required Az modules are present, else, sets them up.
        Includes installing any required Azure modules.
        .INPUTS
        None. You cannot pipe objects to Setup-Prerequisites.
        .OUTPUTS
        Boolean. 'True' if all pre-requisites are met 'False' otherwise.
        .EXAMPLE
        PS> Setup-Prerequisites
        .LINK
        None
    #>
    $allPrerequisiteMet = $true
    # List of required modules
    $requiredModules = @{
        "Az.Accounts" = "2.5.1";
        "Az.Resources" = "1.10.0";
        "Az.Storage" = "2.0.0";
        "Az.ManagedServiceIdentity" = "0.7.3";
        "Az.Monitor" = "1.5.0";
        "Az.OperationalInsights" = "1.3.4";
        "Az.ApplicationInsights" = "1.0.3";
        "Az.Websites" = "2.8.1";
        "Az.Network"  = "2.5.0";
        "Az.FrontDoor" = "1.8.0";
        "AzureAD" = "2.0.2.130";
    }

    $requiredModuleNames = @()
    $requiredModules.Keys | ForEach-Object { $requiredModuleNames += $_.ToString()}

    try{

        #Write-Host "$([Constants]::PreRequisitesInstructionMsg)" -ForegroundColor $([Constants]::MessageType.Info)
        #Write-Host "NOTE: If you want, you can skip this step but if all required modules (with required version) are not available then setup might not get completed." -ForegroundColor $([Constants]::MessageType.Warning)
        #Write-Host $([Constants]::SingleDashLine)
        Write-Host "Checking if all required modules are present..." -ForegroundColor $([Constants]::MessageType.Info)
        #Write-Host "Required powershell modules: $($requiredModules | FT | Out-String)" -ForegroundColor $([Constants]::MessageType.Info)
        $availableModules = $(Get-Module -ListAvailable $requiredModuleNames -ErrorAction Stop) | Select-Object Name, Version | Sort-Object -Property "Version" -Descending

        # Check if the required modules are installed.
        $installedModules = @()
        $missingModules = @()
        $requiredModules.Keys | ForEach-Object {
            $requiredModule = "" | Select-Object "Name", "RequiredVersion"
            $requiredModule.RequiredVersion = $requiredModules[$_]
            $requiredModule.Name = $_
            $modulePresent =  $availableModules | Where-Object {($_.Name -eq $requiredModule.Name) -and ($_.Version -ge $requiredModule.RequiredVersion)} | Select-Object -First 1
            if ($modulePresent)
            {
                $installedModules += $requiredModule
            }
            else
            {
                $missingModules += $requiredModule
            }
        }

        if (($missingModules | Measure-Object).Count -eq 0)
        {
            $allPrerequisiteMet = $true
            Write-Host "All required modules are present." -ForegroundColor $([Constants]::MessageType.Update)
        }
        else
        {
            Write-Host "Installing missing modules..." -ForegroundColor $([Constants]::MessageType.Info)
            Write-Host "Following modules (with required version) are not present:" -ForegroundColor $([Constants]::MessageType.Warning)
            Write-Host $($missingModules | FT | Out-String) -ForegroundColor $([Constants]::MessageType.Info)

            $userChoice = Read-Host -Prompt "Do you want to install all missing modules (Y/N)"
            if ($userChoice -eq "Y")
            {
                $missingModules |  ForEach-Object {
                    Write-Host "Installing $($_.Name) module..." -ForegroundColor $([Constants]::MessageType.Info)
                    Install-Module -Name $_.Name -Scope CurrentUser -Repository 'PSGallery' -ErrorAction Stop -Force
                    if ($?)
                    {
                        $allPrerequisiteMet = $allPrerequisiteMet -and $true
                        Write-Host "Successfully installed $($_.Name) module." -ForegroundColor $([Constants]::MessageType.Update)
                    }
                    else
                    {
                        $allPrerequisiteMet = $allPrerequisiteMet -and $false
                        Write-Host "Unable to install $($_.Name) module." -ForegroundColor $([Constants]::MessageType.Warning)
                    }
                }
                
            }
            else
            {
                $allPrerequisiteMet = $false
                Write-Host "Module installation skipped based on user's choice." -ForegroundColor $([Constants]::MessageType.Info)
            }
        }
    }
    catch
    {
        $allPrerequisiteMet = $false
    }
    
    return $allPrerequisiteMet;
}