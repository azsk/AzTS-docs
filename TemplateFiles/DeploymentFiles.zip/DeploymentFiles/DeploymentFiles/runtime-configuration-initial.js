window.__UI_CONFIGURATION_INITIAL__ = {
    "tenantId": "e60f12c0-e1dc-4be1-8d86-e979a5527830",
    "webAPI": "https://AzSK-AzTS-WebApi-baa32.azurewebsites.net",
    "clientId": "3cc72761-17a1-48c3-beae-389b8c012436",
    "apiClientId": "3ef9b7a6-c217-4a43-b56d-d07d1c7d9d21",
    "azureADAuthURL": "https://login.microsoftonline.com"
};

window.__UI_CONFIGURATION_EXTENDED__ = {};
