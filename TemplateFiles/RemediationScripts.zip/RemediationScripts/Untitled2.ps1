﻿$body =@'
                    {
                        "properties": {0},
                        "location":"{1}"
                    }         
'@
            $content = $body.Replace("{1}",$response.location)
            
            $response.properties.ipConfigurations[0].properties.publicIPAddress = "/subscriptions/abb5301a-22a4-41f9-9e5f-99badff261f8/resourceGroups/v-prsomaniTestRG/providers/Microsoft.Network/publicIPAddresses/BastionVnet-ip"
            $properties = (ConvertTo-Json  $response.Properties)
            $content = $content.Replace("{0}",$properties)



                       Disable-BastionShareableLink -SubscriptionId abb5301a-22a4-41f9-9e5f-99badff261f8 -PerformPreReqCheck -FilePath C:\Users\v-prsomani\AppData\Local\AzTS\Remediation\Subscriptions\abb5301a_22a4_41f9_9e5f_99badff261f8\202306150644\ShareableLinkForBastion\NonCompliantBastion.csv
                       -FilePath C:\Users\v-prsomani\AppData\Local\AzTS\Remediation\Subscriptions\abb5301a_22a4_41f9_9e5f_99badff261f8\202306150636\ShareableLinkForBastion\NonCompliantBastion.csv

Connect-AzAccount -Tenant 72f988bf-86f1-41af-91ab-2d7cd011db47


Enable-BastionShareableLink -SubscriptionId abb5301a-22a4-41f9-9e5f-99badff261f8 -PerformPreReqCheck -FilePath   C:\Users\v-prsomani\AppData\Local\AzTS\Remediation\Subscriptions\abb5301a_22a4_41f9_9e5f_99badff261f8\202306150645\ShareableLinkForBastion\RemediatedBastion.csv
Bastion.csv

